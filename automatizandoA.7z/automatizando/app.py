
import pyautogui 
import keyboard
from time import sleep

# Logar com tela dividida:
pyautogui.click(1014,99, duration=1)
pyautogui.click(1079,249, duration=1)
pyautogui.click(1514,297, duration=1)
pyautogui.click(1540,358, duration=1)
pyautogui.click(1494,372,  duration=1)
# pyautogui.keyDown('ctrl + shift')
# pyautogui.press('shift')
# pyautogui.press('shift')
# pyautogui.keyUp('')
# # ----------------------------------------
# #Escolher Inst:
pyautogui.click(1071,186, duration=1)
# #Mostrar detalhes;
pyautogui.click(1138,656, duration=1)
# #Campo CNPJ pesq;
pyautogui.click(1482,918, duration=0.7)
# #Selecionando e copiando CNPJ pesq;
pyautogui.keyDown('ctrl')
pyautogui.press('a')
# pyautogui.keyDown('ctrl')
# pyautogui.press('c')
# #Clicando e colando no campo CGC em Buscar Instituição;
# pyautogui.click(1421,543, duration=0.7)
# pyautogui.keyDown('ctrl')
# pyautogui.press('v')
# #Clicando em Buscar;
# pyautogui.click(1432,632, duration=0.7)

#Consultar CNPJ
# pyautogui.click(1232,25, duration=0.7)
# pyautogui.click(1239,94, duration=0.7)
# pyautogui.click(1469,673, duration=0.7)
# pyautogui.click(1204,641, duration=0.7)







# 1908,425 f
# 1521,232 f
# 1907,220 f
# 1556,581 f
# 1469,673 f